const $ = (id) => document.getElementById(id);
const form = $('chatForm'), input = $('messageInput'), messagesEl = $('messages'), welcome = $('welcome'), sendBtn = $('sendBtn');
let messages = [];
let chats = JSON.parse(localStorage.getItem('orvyxa_chats') || '[]');
let deferredInstall = null;

function saveChats(){ localStorage.setItem('orvyxa_chats', JSON.stringify(chats.slice(0,20))); renderHistory(); }
function renderHistory(){ $('historyList').innerHTML=''; chats.slice(0,8).forEach((chat,i)=>{const b=document.createElement('button');b.className='history-item';b.textContent=chat.title||'Conversation';b.onclick=()=>loadChat(i);$('historyList').append(b);}); }
function loadChat(i){ messages=chats[i].messages||[]; renderMessages(); $('sidebar').classList.remove('open'); }
function newChat(){ if(messages.length){chats.unshift({title:messages.find(m=>m.role==='user')?.content.slice(0,38)||'Conversation',messages:[...messages]});saveChats();} messages=[];messagesEl.innerHTML='';messagesEl.classList.remove('visible');welcome.hidden=false;input.value='';$('sidebar').classList.remove('open'); }
function addMessage(role,content){messages.push({role,content});renderMessages();}
function renderMessages(){welcome.hidden=messages.length>0;messagesEl.classList.toggle('visible',messages.length>0);messagesEl.innerHTML='';for(const m of messages){const row=document.createElement('div');row.className='message '+m.role;const av=document.createElement('div');av.className='message-avatar';av.textContent=m.role==='user'?'V':'N';const body=document.createElement('div');body.className='message-body';body.textContent=m.content;row.append(av,body);messagesEl.append(row);}messagesEl.scrollTop=messagesEl.scrollHeight;}
function toast(text){const el=$('toast');el.textContent=text;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2800);}
async function sendMessage(text){text=text.trim();if(!text||sendBtn.disabled)return;addMessage('user',text);input.value='';input.style.height='auto';sendBtn.disabled=true;const waiting={role:'assistant',content:'ORVYXA réfléchit…'};messages.push(waiting);renderMessages();messagesEl.lastElementChild.querySelector('.message-body').classList.add('typing');try{const res=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:messages.filter(m=>m!==waiting)})});const data=await res.json();if(!res.ok)throw new Error(data.error||'Erreur de connexion.');waiting.content=data.answer||'Pas de réponse.';waiting.content=waiting.content;}catch(e){waiting.content='⚠ '+e.message;}finally{renderMessages();sendBtn.disabled=false;chats.unshift({title:messages.find(m=>m.role==='user')?.content.slice(0,38)||'Conversation',messages:[...messages]});saveChats();input.focus();}}
form.addEventListener('submit',e=>{e.preventDefault();sendMessage(input.value);});
input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();form.requestSubmit();}});
input.addEventListener('input',()=>{input.style.height='auto';input.style.height=Math.min(input.scrollHeight,150)+'px';});
$('newChat').onclick=newChat;$('homeLink').onclick=newChat;$('historyLink').onclick=()=>$('historyList').scrollIntoView({behavior:'smooth'});$('menuToggle').onclick=()=>$('sidebar').classList.toggle('open');
document.querySelectorAll('.suggestion').forEach(b=>b.addEventListener('click',()=>{input.value=b.dataset.prompt;sendMessage(input.value);}));
renderHistory();
fetch('/api/status').then(r=>r.json()).then(s=>{if(!s.configured)toast('Configure la clé API pour activer les réponses IA.');}).catch(()=>{});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e;$('installBtn').hidden=false;});
$('installBtn').addEventListener('click',async()=>{if(!deferredInstall)return;deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null;$('installBtn').hidden=true;});
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
