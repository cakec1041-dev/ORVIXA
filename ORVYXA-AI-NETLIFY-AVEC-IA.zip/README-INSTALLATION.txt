ORVYXA AI — version Netlify avec fonction IA

IMPORTANT : ce ZIP doit etre deploye avec une methode qui lance le build Netlify
(par exemple une connexion a un depot Git). Le depot manuel Netlify Drop publie
les fichiers statiques mais ne construit pas les fonctions serveur.

ETAPES :
1. Decompresser cette archive.
2. Mettre tout le contenu dans un depot GitHub prive.
3. Dans Netlify : Add new project > Import an existing project, puis choisir ce depot.
4. Verifier que le dossier publie est "site" et que le dossier Functions est "netlify/functions".
   Le fichier netlify.toml configure deja ces chemins.
5. Dans Netlify > Project configuration > Environment variables, ajouter :
   OPENAI_API_KEY = cle API du compte gere par un adulte responsable.
   Facultatif : OPENAI_MODEL = gpt-6-luna
6. Redeployer le site.

SECURITE :
- Ne jamais mettre la cle API dans site/app.js, dans le ZIP public, ni dans un message.
- Ne jamais envoyer la cle API a ChatGPT ou a quelqu'un d'autre.
- L'API peut generer des frais selon l'utilisation. Un adulte doit gerer le compte,
  verifier les conditions d'age et configurer les limites de depenses.
- Le site est public : des visiteurs peuvent envoyer des requetes au moteur IA.
