import OpenAI from "openai";

export default async (request) => {
  if (request.method !== "POST") {
    return Response.json({ error: "Methode non autorisee." }, { status: 405 });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return Response.json(
      { error: "Le moteur IA n'est pas configure. Ajoute OPENAI_API_KEY dans les variables Netlify." },
      { status: 503 }
    );
  }

  try {
    const body = await request.json();
    const messages = body?.messages;

    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 30) {
      return Response.json({ error: "Conversation invalide." }, { status: 400 });
    }

    const input = messages.slice(-20).map((message) => {
      if (!["user", "assistant"].includes(message?.role) ||
          typeof message?.content !== "string") {
        throw new Error("Message invalide.");
      }
      return { role: message.role, content: message.content.slice(0, 8000) };
    });

    const client = new OpenAI({ apiKey });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-luna",
      instructions: "Tu es ORVYXA, un assistant IA utile, clair, honnete et bienveillant. Reponds dans la langue de la personne. Explique simplement et n'invente pas de faits. Pour les demandes risquees, privilegie la securite.",
      input
    });

    return Response.json({
      answer: response.output_text || "Je n'ai pas reussi a produire une reponse."
    });
  } catch (error) {
    console.error("ORVYXA chat error:", error?.message || error);
    return Response.json(
      { error: "Une erreur est survenue. Verifie la configuration du serveur puis reessaie." },
      { status: 500 }
    );
  }
};
