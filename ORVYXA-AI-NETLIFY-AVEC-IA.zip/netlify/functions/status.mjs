export default async () => {
  return Response.json({
    configured: Boolean(process.env.OPENAI_API_KEY)
  });
};
